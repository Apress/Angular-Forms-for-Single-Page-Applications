﻿using System;
using System.Collections.Generic;

namespace WebApiDemo.Models;

public partial class ProductMaster
{
    public int ProductId { get; set; }

    public string? ProductName { get; set; }

    public int? Qty { get; set; }
}
