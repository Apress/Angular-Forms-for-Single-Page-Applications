﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiDemo.Models;

namespace WebApiDemo.Controllers
{

    public class ProductsController : ControllerBase
    {
        ProductsDbContext db;
        [Route("~/api/products/getproducts")]
        [HttpGet]
        public IActionResult GetProducts()
        {
            db = new ProductsDbContext();
            var query  = db.ProductMasters.ToList();
            return Ok(query);
        }

        
        [Route("~/api/products/addproduct")]
        [HttpPost]
        public IActionResult SaveProduct([FromBody] Product product)
        {
            try
            {
                db = new ProductsDbContext();
                ProductMaster productMaster = new ProductMaster();
                productMaster.ProductId = product.ProductId;
                productMaster.ProductName = product.ProductName;
                productMaster.Qty = product.Qty;
                db.ProductMasters.Add(productMaster);
                db.SaveChanges();
                return Ok(true);
            }
            catch (Exception ex)
            {
                return BadRequest(false);
            }
        }

        [Route("")]
        [HttpGet]
        public IActionResult GetProducts(int productId)
        {
            db = new ProductsDbContext();
            var query = db.ProductMasters.Find(productId);
            return Ok(query);
        }
    }
}
