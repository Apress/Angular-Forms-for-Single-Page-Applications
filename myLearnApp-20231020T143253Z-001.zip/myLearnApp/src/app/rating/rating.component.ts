import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent {
  public form: FormGroup;
  constructor(private fb: FormBuilder){
    this.form = this.fb.group({
      rating: ['', Validators.required],
    })
  }
}
