import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-viewproduct',
  templateUrl: './viewproduct.component.html',
  styleUrls: ['./viewproduct.component.css']
})
export class ViewproductComponent implements OnInit {
  products: any[] = [];
  constructor(private productService: ProductService) {
    
    
  }
  ngOnInit(): void {
    this.productService.getProducts()
    .subscribe({next:(productm)=>{
      debugger
        console.log(productm);
        this.products = productm;
    }
  })
  }
}

