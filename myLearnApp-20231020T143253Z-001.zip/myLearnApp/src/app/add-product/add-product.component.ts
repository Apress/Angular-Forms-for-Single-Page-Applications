import { Component } from '@angular/core';
import { ProductService } from 'src/app/product.service';
import { FormControl, FormGroup } from '@angular/forms';
import { numberFormat } from 'highcharts';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {

  constructor(private service: ProductService) {
  }

  //productModel: ProductModel; //= new ProductModel;
  productForm = new FormGroup({
    ProductId: new FormControl(''),
    ProductName: new FormControl(''),
    Qty: new FormControl('')
  });

  saveProduct() {
    console.log(this.productForm);

    // this.productModel.ProductId = 6//this.productForm.value.Id
    // this.productModel.ProductName = "dffd"//this.productForm.value.ProductName
    // this.productModel.Qty = 4//this.productForm.value.Qty
debugger
    // this.service.addProduct(this.productModel).subscribe(data => {
      
    // });
  }
}
