import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxdemoComponent } from './checkboxdemo.component';

describe('CheckboxdemoComponent', () => {
  let component: CheckboxdemoComponent;
  let fixture: ComponentFixture<CheckboxdemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CheckboxdemoComponent]
    });
    fixture = TestBed.createComponent(CheckboxdemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
