import { Component } from '@angular/core';


@Component({
  selector: 'app-checkboxdemo',
  templateUrl: './checkboxdemo.component.html',
  styleUrls: ['./checkboxdemo.component.css']
})
export class CheckboxdemoComponent {

  bookList: any[] = [];

  ngOnInit() {
    this.bookList = [
      {
        id: 1,
        title: 'Practical Highcharts with Angular',
        checked: true,
      },
      {
        id: 2,
        title: 'Angular : Introduction',
        checked: false,
      },
      {
        id: 3,
        title: 'Practical VSCode',
        checked: false,
      },
      {
        id: 4,
        title: 'Practical C++',
        checked: false,
      },
    ]
  }

  get result() {
    return this.bookList.filter(item => item.checked);
  }

}
