import { Component } from '@angular/core';
import { ProductService } from 'src/app/product.service';

@Component({
  selector: 'app-show-product',
  templateUrl: './show-product.component.html',
  styleUrls: ['./show-product.component.css']
})
export class ShowProductComponent {
  constructor(private service: ProductService) {

  }
  list :any=[];

 ngOnInit(): void {
    this.service.getProducts()
      this.service.getProducts().subscribe(data => {
      
      this.list=data;
      console.log(this.list)
    });  
 }
}
