export interface ProductModel
{
    ProductId: number;
    ProductName: string;
    Qty: number;
}