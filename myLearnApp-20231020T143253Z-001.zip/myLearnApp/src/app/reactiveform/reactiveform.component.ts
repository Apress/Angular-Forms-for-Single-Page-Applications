import { Component } from '@angular/core';
import{ ReactiveFormsModule } from'@angular/forms';
import{ FormGroup, FormControl } from'@angular/forms'

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent {
  studentForm = new FormGroup({
    email:new FormControl(''),
    FirstName:new FormControl(''),
    LastName:new FormControl(''),
  });

  AddStudent()
  {
      console.log(this.studentForm);
  }


}
