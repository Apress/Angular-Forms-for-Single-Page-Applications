import { Component } from '@angular/core';
import { ProductService } from 'src/app/product.service';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { ProductModel } from '../models/productModel';


@Component({
  selector: 'app-add-product-form',
  templateUrl: './add-product-form.component.html',
  styleUrls: ['./add-product-form.component.css']
})
export class AddProductFormComponent {
    url: string = 'http://localhost:5033/api/';
    addForm!: FormGroup;
  
  constructor(private productService: ProductService) { }
product:ProductModel = {
  ProductId:0,
  ProductName:'',
  Qty:0
}


  onSubmit() {
    this.productService.addProduct(this.url, this.product)
    .subscribe({next:(productm)=>{
        console.log(productm);
    }
  })
    
   

    }
}
