import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductModel } from './models/productModel';



@Injectable({
  providedIn: 'root'
})
export class ProductService {
  readonly apiUrl = 'http://localhost:5033/api/';

    constructor(private http: HttpClient) { }
 getProducts(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'products/GetProducts');
  }
  
  addProduct(url:any,productModel: ProductModel):Observable<ProductModel> {
    debugger
    return this.http.post<ProductModel>(url + 'products/addproduct', productModel);
  }




}
